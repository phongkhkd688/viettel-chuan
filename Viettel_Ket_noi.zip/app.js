'use strict';
const $ = (s) => document.querySelector(s);
const esc = (v = '') => String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clean = (v='')=>v.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d');
const read = (key,fallback)=>{try{return JSON.parse(localStorage.getItem('ketnoi:'+key))??fallback}catch{return fallback}};
const save = (key,value)=>localStorage.setItem('ketnoi:'+key,JSON.stringify(value));
const kinds=['Di động','Internet CĐBR','Truyền hình','Dịch vụ số','Data di động','Doanh nghiệp'];
const icons=['▯','◔','▣','✦','▥','▤'];
const types=['Chung cư','Khu đô thị','Khu dân cư','Khu công nghiệp','Văn phòng','Trung tâm thương mại','Khách sạn / Resort','Khác'];
const groups=['Cá nhân','Hộ gia đình','Doanh nghiệp','Ban quản lý dự án'];
const statuses=['Mới tiếp nhận','Đang tư vấn','Đã hẹn triển khai','Hoàn tất','Đã hủy'];
const official='https://www.viettel.vn';
const catalog=[
 ['fiber',1,'Internet Viettel NETVT01','Internet cáp quang 300 Mbps. Kiểm tra địa chỉ, thiết bị và cước theo địa bàn.','Kiểm tra cước theo địa chỉ',official+'/vx/internet-truyenhinh/goi-cuoc/NETVT01'],
 ['combo',1,'Internet + TV360','Gói NETVT01H_GIAITRI kết hợp Internet 300 Mbps và truyền hình TV360.','Kiểm tra cước theo địa chỉ',official+'/vx/internet-truyenhinh/goi-cuoc/NETVT01H_GIAITRI'],
 ['esim',0,'SIM / eSIM Viettel','Tư vấn hòa mạng eSIM và kiểm tra thiết bị tương thích.','Xem điều kiện hòa mạng','https://esim.viettel.vn/'],
 ['tv',2,'Truyền hình TV360','Xem truyền hình và nội dung theo yêu cầu. Chọn gói theo thiết bị và nhu cầu.','Xem bảng giá TV360','https://tv360.vn/packages'],
 ['sd90',4,'Gói data SD90','Kiểm tra điều kiện đăng ký theo thuê bao. Cú pháp được Viettel công bố: SD90 gửi 191.','Xem cước và dung lượng',official+'/vx/di-dong/goi-data/SD90'],
 ['data',4,'Gói data 4G/5G','Tra cứu dung lượng, chu kỳ và gói áp dụng cho thuê bao Viettel.','Tra cứu gói theo thuê bao',official+'/goi-data'],
 ['sign',3,'My Sign Viettel','Chữ ký số từ xa cho cá nhân và tổ chức. Kiểm tra hồ sơ và gói dịch vụ tại nguồn.','Xem gói và thủ tục','https://shop.viettel.vn/mysign'],
 ['biz',5,'Kết nối cho doanh nghiệp','Tiếp nhận nhu cầu khảo sát Internet và kết nối cho văn phòng, cơ sở kinh doanh hoặc dự án.','Yêu cầu khảo sát',official+'/vx/internet-truyenhinh/goi-cuoc/NETVT01']
];
const offer=['tv-deal','TV360 giảm 30% cho chu kỳ đầu','Áp dụng 11/09–31/12/2026 với Standard, VIP Mobile, VSport và VCine chu kỳ 30 ngày, qua phương thức thanh toán đủ điều kiện. Ưu đãi loại trừ đăng ký qua tư vấn viên kênh bán tại tỉnh/thành phố.','https://www.vietteltelecom.vn/tin-tuc/chi-tiet/tv360-giam-30-gia-goi-cuoc-tan-huong-giai-tri-chi-tu-21000-dongthang/15965268'];
const sampleProjects=[['m1','Chung cư An Phú',0,'Hà Nội','Chờ khảo sát'],['m2','Khu đô thị Bình Minh',1,'Hà Nội','Chờ khảo sát'],['m3','Khu công nghiệp Đông Thành',3,'Bắc Ninh','Chờ khảo sát']];
const base={name:'Viettel Kết nối',phone:'',email:'',headline:'Kết nối Viettel cho mọi nhu cầu',banner:'',bannerName:'',bannerText:'',bannerLink:'',officialOffer:true,demo:true};
let cfg=read('config',base), orders=read('orders',[]), projects=read('projects',[]), events=read('events',[]);
const fdate = new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit'});
const day=(v=new Date())=>fdate.format(v);
const money=(n)=>new Intl.NumberFormat('vi-VN',{maximumFractionDigits:0}).format(n)+' ₫';
const options=(a)=>a.map((x,i)=>'<option value="'+i+'">'+esc(x)+'</option>').join('');
const safeUrl=(v)=>{try{let u=new URL(v);return u.protocol==='https:'?u.href:''}catch{return ''}};
const ext=(url,label)=>'<a class="source" target="_blank" rel="noopener" href="'+esc(url)+'">'+esc(label)+'</a>';
const btn=(label,attrs='',cls='')=>'<button type="button" class="'+cls+'" '+attrs+'>'+label+'</button>';
const title=(k,t,p)=>'<div class="eyebrow">'+k+'</div><h1 class="page-title">'+t+'</h1><p class="muted">'+p+'</p>';
const empty=(message)=>'<p class="empty">'+message+'</p>';
const source=(p)=>ext(p[5],'Chính sách Viettel');
const groupOptions=()=>options(groups);
function record(type,id=''){events.push({type,id,day:day()});events=events.slice(-5000);save('events',events)}
function flash(message){$('#notice').textContent=message;$('#notice').hidden=false;clearTimeout(flash.timer);flash.timer=setTimeout(()=>$('#notice').hidden=true,3800)}
function showModal(heading,content){const d=$('#modal');d.innerHTML='<div class="heading"><h2 id="modal-title">'+esc(heading)+'</h2>'+btn('×','data-close aria-label="Đóng"','close secondary')+'</div>'+content;if(!d.open)d.showModal()}
function serviceCard(p){return '<article class="card"><span class="icon" aria-hidden="true">'+icons[p[1]]+'</span><span class="tag">'+kinds[p[1]]+'</span><h3>'+p[2]+'</h3><p>'+p[3]+'</p><div class="price">'+p[4]+'</div><div class="actions">'+btn('Đăng ký tư vấn','data-buy="'+p[0]+'"')+source(p)+'</div></article>'}
function offerCards(){
 const out=[];
 if(cfg.officialOffer&&day()<='2026-12-31')out.push('<article class="card adv"><span class="tag">Nguồn Viettel</span><h3>'+offer[1]+'</h3><p>'+offer[2]+'</p>'+ext(offer[3],'Xem thể lệ chính thức')+'</article>');
 if(cfg.bannerName)out.push('<article class="card adv">'+(cfg.banner?'<img class="promo" alt="" src="'+esc(cfg.banner)+'">':'')+'<span class="tag">Tin từ người bán</span><h3>'+esc(cfg.bannerName)+'</h3><p>'+esc(cfg.bannerText)+'</p>'+(safeUrl(cfg.bannerLink)?ext(safeUrl(cfg.bannerLink),'Xem thông tin'):'')+'</article>');
 return out.join('')||empty('Hiện chưa có chương trình đang hiển thị.');
}
function projectCard(p){
 return '<article class="card"><span class="icon" aria-hidden="true">▤</span><span class="tag">'+types[p[2]]+(p[0].startsWith('m')?' · Minh họa':'')+'</span><h3>'+esc(p[1])+'</h3><p>'+esc(p[3])+'</p><b>'+esc(p[4])+'</b>'+btn('Yêu cầu khảo sát','data-buy="fiber" data-project="'+esc(p[0])+'"','soft')+'</article>';
}
function allProjects(){return [...projects,...(cfg.demo?sampleProjects:[])]}
function home(){return '<section class="hero"><div><div class="eyebrow">Internet Viettel theo dự án</div><h1>'+esc(cfg.headline)+'</h1><p>Tra cứu Internet cáp quang theo địa chỉ, tìm gói di động và chọn dịch vụ cho gia đình hoặc doanh nghiệp.</p><div class="actions"><a class="button" href="#projects">Tìm dự án lắp đặt</a><a class="button dark" href="#catalog">Khám phá dịch vụ</a></div></div></section><div class="quick">'+kinds.map((k,i)=>'<a href="#catalog/'+i+'"><span class="icon" aria-hidden="true">'+icons[i]+'</span>'+k+'</a>').join('')+'</div><section class="section"><div class="heading"><div><div class="eyebrow">Internet cáp quang</div><h2>Lắp đặt theo dự án</h2></div><a class="button outline" href="#projects">Tra cứu dự án</a></div><div class="grid">'+(allProjects().slice(0,3).map(projectCard).join('')||empty('Gửi địa chỉ để người bán khảo sát hạ tầng.'))+'</div></section><section class="section"><div class="heading"><h2>Dịch vụ nổi bật</h2><a class="button outline" href="#catalog">Xem tất cả</a></div><div class="grid">'+[catalog[0],catalog[2],catalog[3]].map(serviceCard).join('')+'</div></section><section class="section"><div class="heading"><h2>Ưu đãi đang hiển thị</h2></div><div class="grid">'+offerCards()+'</div></section>'}
function findPage(route,arg){
 const isProjects=route==='projects';
 return title(isProjects?'Internet cố định':'Danh mục Viettel',isProjects?'Tra cứu dự án CĐBR':'Sản phẩm và dịch vụ',isProjects?'Tìm theo tên dự án hoặc địa bàn. Hạ tầng được xác nhận theo địa chỉ lắp đặt.':'Chọn nhóm dịch vụ và xem điều kiện trên cổng Viettel trước khi gửi đăng ký.')+
 '<div class="filters"><input id="search" aria-label="Từ khóa tra cứu" type="search" placeholder="'+(isProjects?'Tên dự án, tỉnh/thành phố…':'Tên gói, mã gói, dịch vụ…')+'"><select id="category" aria-label="Nhóm tra cứu"><option value="">'+(isProjects?'Tất cả loại dự án':'Tất cả dịch vụ')+'</option>'+options(isProjects?types:kinds)+'</select>'+(isProjects?btn('Khảo sát địa chỉ khác','data-buy="fiber"','soft'):'')+'</div><div id="results" class="grid"></div>';
}
function filter(route){
 const q=clean($('#search').value.trim()), c=$('#category').value;
 const matches=route==='projects'?allProjects().filter(p=>(c===''||Number(c)===p[2])&&clean(p[1]+' '+p[3]+' '+types[p[2]]).includes(q)).map(projectCard):catalog.filter(p=>(c===''||Number(c)===p[1])&&clean(p[2]+' '+p[3]+' '+kinds[p[1]]).includes(q)).map(serviceCard);
 $('#results').innerHTML=matches.join('')||empty('Không có kết quả phù hợp.');
}
function checkout(id,projectId){
 const p=catalog.find(row=>row[0]===id), project=allProjects().find(row=>row[0]===projectId); if(!p)return;
 record('open',id);
 showModal('Đăng ký '+(p[1]===1?'khảo sát':'tư vấn'),'<p><strong>'+p[2]+'</strong>'+(project?' · '+esc(project[1]):'')+'</p><form class="form formgrid" id="buy-form"><label>Họ và tên<input name="name" required maxlength="100" autocomplete="name"></label><label>Số điện thoại<input name="phone" required type="tel" pattern="[+]?[0-9 .()-]{8,18}" maxlength="18" autocomplete="tel"></label><label>Nhóm khách hàng<select name="group">'+groupOptions()+'</select></label><label>Email (tùy chọn)<input name="email" type="email" maxlength="140" autocomplete="email"></label><label class="full">'+(p[1]===1?'Địa chỉ lắp đặt':'Địa chỉ (tùy chọn)')+'<input name="address" maxlength="200" '+(p[1]===1?'required':'')+'></label><label class="full">Nhu cầu / thời gian liên hệ<textarea name="note" maxlength="600"></textarea></label><label class="consent full"><input type="checkbox" required> Tôi đồng ý cung cấp thông tin để người bán tư vấn yêu cầu này.</label><button class="full">Tạo yêu cầu tư vấn</button></form>');
 $('#buy-form').onsubmit=(e)=>{
  e.preventDefault();const fields=Object.fromEntries(new FormData(e.currentTarget));const o={...fields,id:'VT-'+crypto.randomUUID().slice(0,8).toUpperCase(),service:id,project:project?.[1]||'',created:day(),status:0,amount:0,closed:''};
  const next=[o,...orders];try{save('orders',next)}catch{flash('Không thể lưu yêu cầu trên trình duyệt này.');return}
  orders=next;record('submit',id);
  const msg='Yêu cầu '+o.id+' · '+p[2]+'\nKhách hàng: '+o.name+' · '+o.phone+'\nEmail: '+o.email+'\nDự án: '+o.project+'\nĐịa chỉ: '+o.address+'\nNhu cầu: '+o.note;
  const contact=(cfg.email?'<a class="button" href="mailto:'+esc(cfg.email)+'?subject='+encodeURIComponent('Yêu cầu '+o.id)+'&amp;body='+encodeURIComponent(msg)+'">Mở email gửi người bán</a>':'')+(cfg.phone?'<a class="button outline" href="sms:'+esc(cfg.phone.replace(/[^+0-9]/g,''))+'?body='+encodeURIComponent(msg)+'">Mở SMS</a><a class="button outline" href="tel:'+esc(cfg.phone.replace(/[^+0-9]/g,''))+'">Gọi người bán</a>':'');
  showModal('Đã lưu yêu cầu', '<p>Mã tra cứu <strong>'+o.id+'</strong>. Yêu cầu được lưu trên trình duyệt này.</p><p class="muted">'+(contact?'Chọn kênh bên dưới và xác nhận gửi trong ứng dụng của bạn.':'Người bán chưa thiết lập email hoặc số điện thoại nhận yêu cầu.')+'</p><div class="actions">'+contact+'<a class="button outline" href="#track" data-close>Tra cứu yêu cầu</a></div>');
 };
}
function ownerTabs(route){return '<div class="tabs">'+[['orders','Đơn hàng'],['manage-projects','Dự án CĐBR'],['report','Báo cáo'],['settings','Tùy biến website']].map(([r,t])=>'<a class="'+(r===route?'active':'')+'" href="#'+r+'">'+t+'</a>').join('')+'</div><div class="band minor">Bản dùng thử. Cấu hình và dữ liệu đơn hàng lưu trên trình duyệt hiện tại.</div>'}
function ordersTable(){
 const q=clean($('#order-q').value), status=$('#order-status').value;
 const matching=orders.filter(o=>(status===''||Number(status)===o.status)&&clean(o.id+' '+o.name+' '+o.phone+' '+o.project+' '+(catalog.find(p=>p[0]===o.service)?.[2]||'')).includes(q));
 $('#order-list').innerHTML=matching.length?'<div class="table-wrap"><table><thead><tr><th>Mã / Ngày nhận</th><th>Khách hàng</th><th>Dịch vụ / Dự án</th><th>Trạng thái</th><th>Doanh thu (₫)</th><th></th></tr></thead><tbody>'+matching.map(o=>'<tr data-row="'+o.id+'"><td><strong>'+o.id+'</strong><br>'+o.created+'</td><td>'+esc(o.name)+'<br>'+esc(o.phone)+'<br><small>'+groups[o.group]+'</small></td><td>'+esc(catalog.find(p=>p[0]===o.service)?.[2])+(o.project?'<br>'+esc(o.project):'')+'<br>'+btn('Chi tiết','data-detail="'+o.id+'"','link')+'</td><td><select aria-label="Trạng thái '+o.id+'">'+statuses.map((s,i)=>'<option value="'+i+'" '+(i===o.status?'selected':'')+'>'+s+'</option>').join('')+'</select></td><td><input type="number" min="0" max="1000000000000" step="1" value="'+o.amount+'" aria-label="Doanh thu '+o.id+'"></td><td>'+btn('Lưu','data-save-order="'+o.id+'"','secondary')+'</td></tr>').join('')+'</tbody></table></div>':empty('Chưa có đơn hàng phù hợp. Đơn tạo từ popup đăng ký sẽ xuất hiện ở đây.');
}
function editProject(id){
 const p=projects.find(x=>x[0]===id);
 showModal(p?'Sửa dự án':'Thêm dự án','<form id="project-form" class="form formgrid"><label>Tên dự án<input required name="name" maxlength="100" value="'+esc(p?.[1])+'"></label><label>Loại dự án<select name="type">'+options(types)+'</select></label><label>Địa bàn / địa chỉ<input name="address" required maxlength="160" value="'+esc(p?.[3])+'"></label><label>Trạng thái hạ tầng<select name="status">'+['Chờ khảo sát','Đang khảo sát','Có thể tiếp nhận','Tạm dừng tiếp nhận'].map(s=>'<option '+(s===p?.[4]?'selected':'')+'>'+s+'</option>').join('')+'</select></label><button class="full">Lưu dự án</button></form>');
 const form=$('#project-form');form.elements.type.value=p?.[2]??0;
 form.onsubmit=(e)=>{e.preventDefault();const f=e.currentTarget.elements;const row=[p?.[0]||crypto.randomUUID(),f.name.value,+f.type.value,f.address.value,f.status.value];projects=p?projects.map(x=>x===p?row:x):[row,...projects];save('projects',projects);$('#modal').close();render(false);flash('Đã lưu dự án.')};
}
function settings(){
 return '<form id="config" class="panel form formgrid"><label>Tên hiển thị<input name="name" required maxlength="70" value="'+esc(cfg.name)+'"></label><label>Tiêu đề trang chủ<input name="headline" required maxlength="100" value="'+esc(cfg.headline)+'"></label><label>Email nhận đăng ký<input name="email" type="email" maxlength="140" value="'+esc(cfg.email)+'"></label><label>Số điện thoại nhận đăng ký<input name="phone" type="tel" pattern="[+]?[0-9 .()-]{8,18}" maxlength="18" value="'+esc(cfg.phone)+'"></label><h3 class="full">Quảng cáo của người bán</h3><label>Tên quảng cáo<input name="bannerName" maxlength="100" value="'+esc(cfg.bannerName)+'"></label><label>Liên kết HTTPS<input name="bannerLink" type="url" maxlength="500" value="'+esc(cfg.bannerLink)+'"></label><label class="full">Nội dung quảng cáo<textarea name="bannerText" maxlength="350">'+esc(cfg.bannerText)+'</textarea></label><label>Ảnh quảng cáo (tối đa 1 MB)<input name="image" type="file" accept="image/png,image/jpeg,image/webp"></label><label class="consent"><input type="checkbox" name="remove"> Bỏ ảnh hiện tại</label><label class="consent"><input type="checkbox" name="officialOffer" '+(cfg.officialOffer?'checked':'')+'> Hiện ưu đãi Viettel</label><label class="consent"><input type="checkbox" name="demo" '+(cfg.demo?'checked':'')+'> Hiện dự án minh họa</label><button class="full">Lưu cấu hình</button></form>';
}
function monthShift(v,delta){const [y,m]=v.split('-').map(Number);return new Date(Date.UTC(y,m-1+delta,1)).toISOString().slice(0,7)}
function stats(m){
 const incoming=orders.filter(o=>o.created.startsWith(m)), won=orders.filter(o=>o.status===3&&o.closed.startsWith(m));
 const converted=incoming.filter(o=>o.status===3).length;
 return {incoming,won,count:incoming.length,sold:won.length,rev:won.reduce((n,o)=>n+o.amount,0),rate:incoming.length?100*converted/incoming.length:0};
}
function change(a,b){return b?((a-b)/b*100>0?'+':'')+((a-b)/b*100).toFixed(1)+'%':a?'Chưa có nền so sánh':'0%'}
function buckets(rows,total){return rows.map(([label,n])=>'<div class="metric"><span>'+esc(label)+'</span><strong>'+n+'</strong></div><div class="bar" aria-hidden="true"><i style="width:'+(total?Math.min(100,n/total*100):0)+'%"></i></div>').join('')}
function report(m){
 if(!/^\d{4}-\d{2}$/.test(m))return;
 const c=stats(m), prior=stats(monthShift(m,-1)), year=stats(monthShift(m,-12)), hits=events.filter(e=>e.day.startsWith(m)), views=hits.filter(e=>e.type==='view').length, opens=hits.filter(e=>e.type==='open').length, sends=hits.filter(e=>e.type==='submit').length;
 const stale=orders.filter(o=>o.status<2&&Date.parse(day())-Date.parse(o.created)>=172800000).length;
 const products=kinds.map((k,i)=>[k,c.incoming.filter(o=>catalog.find(p=>p[0]===o.service)?.[1]===i).length]);const top=products.slice().sort((a,b)=>b[1]-a[1])[0];
 $('#report-data').innerHTML='<div class="kpis">'+[['Yêu cầu mới','count',c.count],['Đơn hoàn tất','sold',c.sold],['Doanh thu hoàn tất','rev',money(c.rev)],['Tỷ lệ chốt yêu cầu','rate',c.rate.toFixed(1)+'%']].map(([l,k,v])=>'<div class="kpi"><span>'+l+'</span><strong>'+v+'</strong><p class="minor muted">So tháng trước: '+change(c[k],prior[k])+'<br>So cùng kỳ: '+change(c[k],year[k])+'</p></div>').join('')+'</div><p class="minor muted">Đơn hoàn tất và doanh thu tính theo ngày hoàn tất. Tỷ lệ chốt tính trên yêu cầu tạo trong kỳ. Hai mức so sánh là biến động tương đối.</p><div class="reportgrid"><section class="panel"><h3>Nhóm sản phẩm dịch vụ</h3>'+buckets(products,c.count)+'</section><section class="panel"><h3>Nhóm khách hàng</h3>'+buckets(groups.map((g,i)=>[g,c.incoming.filter(o=>+o.group===i).length]),c.count)+'</section><section class="panel"><h3>Hành vi trên website</h3>'+buckets([['Lượt mở trang',views],['Lượt mở đăng ký',opens],['Yêu cầu đã tạo',sends]],Math.max(views,opens,sends))+'<small>Tổng lượt trên trình duyệt này, có thể gồm nhiều lượt từ cùng một người.</small></section><section class="panel"><h3>Cảnh báo và khuyến nghị</h3><ul><li>'+(stale?stale+' yêu cầu đang chờ xử lý từ 2 ngày trở lên.':'Không có yêu cầu chờ xử lý từ 2 ngày trở lên.')+'</li><li>'+(opens>=5&&sends/opens<0.4?'Dưới 40% lượt mở biểu mẫu dẫn đến yêu cầu. Rà soát trường nhập và điều kiện gói.':'Theo dõi thêm tỷ lệ tạo yêu cầu sau khi mở biểu mẫu.')+'</li><li>'+(top[1]?esc(top[0])+' được quan tâm nhiều nhất ('+top[1]+' yêu cầu). Ưu tiên rà soát khả năng cung cấp và tư vấn.':'Chưa có yêu cầu trong kỳ để xác định nhóm sản phẩm nổi bật.')+'</li></ul></section></div>';
}
function render(track=true){
 const [route,arg]=location.hash.slice(1).split('/');const r=route||'home';const main=$('#main');
 document.querySelectorAll('nav a').forEach(a=>a.classList.toggle('active',a.dataset.route===r));
 if(track&&['home','catalog','projects','offers','track'].includes(r))record('view',r);
 if(r==='catalog'||r==='projects'){main.innerHTML=findPage(r,arg);if(r==='catalog'&&arg!==undefined&&kinds[+arg])$('#category').value=arg;$('#search').oninput=()=>filter(r);$('#category').onchange=()=>filter(r);filter(r)}
 else if(r==='offers')main.innerHTML=title('Chương trình đang hiển thị','Ưu đãi Viettel','Kiểm tra thời hạn, nhóm gói và điều kiện tại nguồn công bố.')+'<div class="grid">'+offerCards()+'</div>';
 else if(r==='track'){
  main.innerHTML=title('Hỗ trợ khách hàng','Tra cứu yêu cầu','Nhập mã yêu cầu và số điện thoại đã đăng ký trên trình duyệt này.')+'<form id="tracking" class="panel form formgrid"><label>Mã yêu cầu<input name="id" required></label><label>Số điện thoại<input name="phone" type="tel" required></label><button class="full">Tra cứu</button></form><div id="lookup" aria-live="polite"></div>';
  $('#tracking').onsubmit=(e)=>{e.preventDefault();const f=e.currentTarget.elements, norm=(v)=>v.replace(/[^0-9]/g,'').replace(/^84(?=\d{9}$)/,'0');const o=orders.find(o=>o.id===f.id.value.trim().toUpperCase()&&norm(o.phone)===norm(f.phone.value));$('#lookup').innerHTML='<div class="band">'+(o?o.id+' · '+statuses[o.status]+' · Ngày tiếp nhận '+o.created:'Không tìm thấy yêu cầu khớp.')+'</div>'};
 }
 else if(['orders','manage-projects','report','settings'].includes(r)){
  const labels={'orders':'Quản lý đơn hàng','manage-projects':'Quản lý dự án CĐBR','report':'Báo cáo kết quả bán hàng','settings':'Tùy biến website'};
  main.innerHTML=title('Khu vực người bán',labels[r],'')+ownerTabs(r);
  if(r==='orders'){main.insertAdjacentHTML('beforeend','<div class="filters"><input id="order-q" type="search" aria-label="Tìm đơn" placeholder="Mã đơn, tên, điện thoại, dịch vụ…"><select id="order-status" aria-label="Lọc trạng thái"><option value="">Tất cả trạng thái</option>'+options(statuses)+'</select></div><div id="order-list"></div>');$('#order-q').oninput=ordersTable;$('#order-status').onchange=ordersTable;ordersTable()}
  if(r==='manage-projects'){main.insertAdjacentHTML('beforeend','<div class="actions section">'+btn('Thêm dự án','data-edit-project=""')+'</div><div class="grid">'+(projects.map(p=>'<article class="card"><span class="tag">'+types[p[2]]+'</span><h3>'+esc(p[1])+'</h3><p>'+esc(p[3])+'</p><b>'+esc(p[4])+'</b>'+btn('Sửa dự án','data-edit-project="'+p[0]+'"','secondary')+'</article>').join('')||empty('Chưa có dự án do người bán nhập.'))+'</div>')}
  if(r==='report'){main.insertAdjacentHTML('beforeend','<label class="filters">Kỳ báo cáo<input class="period" id="month" type="month" min="2000-01" max="2100-12" value="'+day().slice(0,7)+'"></label><div id="report-data"></div>');$('#month').onchange=e=>report(e.target.value);report($('#month').value)}
  if(r==='settings'){main.insertAdjacentHTML('beforeend',settings());$('#config').onsubmit=async(e)=>{e.preventDefault();const f=e.currentTarget.elements;const img=f.image.files[0];if(img&&(img.size>1048576||!['image/png','image/jpeg','image/webp'].includes(img.type))){flash('Chọn ảnh PNG, JPEG hoặc WebP tối đa 1 MB.');return}if(f.bannerLink.value&&!safeUrl(f.bannerLink.value)){flash('Liên kết quảng cáo phải dùng HTTPS.');return}try{const next={...cfg};for(const k of ['name','headline','phone','email','bannerName','bannerText','bannerLink'])next[k]=f[k].value.trim();next.demo=f.demo.checked;next.officialOffer=f.officialOffer.checked;if(f.remove.checked)next.banner='';if(img)next.banner=await new Promise((ok,no)=>{const reader=new FileReader();reader.onload=()=>ok(reader.result);reader.onerror=no;reader.readAsDataURL(img)});save('config',next);cfg=next;render(false);flash('Đã lưu cấu hình.')}catch{flash('Không thể lưu cấu hình. Kiểm tra dung lượng lưu trữ.')}}}
 }
 else main.innerHTML=home();
 $('#seller').textContent=cfg.name+(cfg.phone?' · '+cfg.phone:'')+(cfg.email?' · '+cfg.email:'');
}
document.addEventListener('click',(e)=>{
 const target=e.target.closest('button,a');if(!target)return;
 if(target.hasAttribute('data-close'))$('#modal').close();
 if(target.dataset.buy)checkout(target.dataset.buy,target.dataset.project);
 if(target.hasAttribute('data-edit-project'))editProject(target.dataset.editProject);
 if(target.dataset.detail){const o=orders.find(x=>x.id===target.dataset.detail);showModal(o.id,'<p><strong>'+esc(o.name)+'</strong> · '+esc(o.phone)+'</p><p>'+esc(o.email||'Chưa có email')+'</p><p>'+esc(o.address||'Chưa có địa chỉ')+'</p><p>'+esc(o.note||'Chưa có ghi chú')+'</p>')}
 if(target.dataset.saveOrder){
  const row=target.closest('tr'), o=orders.find(x=>x.id===target.dataset.saveOrder), amount=row.querySelector('input'), status=+row.querySelector('select').value;
  if(!amount.reportValidity()||amount.value===''){flash('Nhập doanh thu hợp lệ.');return}
  Object.assign(o,{status,amount:+amount.value,closed:status===3?(o.closed||day()):''});save('orders',orders);ordersTable();flash('Đã cập nhật đơn hàng.');
 }
});
window.addEventListener('hashchange',()=>{if($('#modal').open)$('#modal').close();render();window.scrollTo(0,0)});
render();
